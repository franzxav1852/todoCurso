package com.everis.examenuno.ejerciciodos;

import java.util.List;

public class ServicioConsola extends Servicio{
	
	public abstract void exportar(List<String>cadenas);
	 
	private void syso() {
		// TODO Auto-generated method stub
		System.out

	}
	 

}

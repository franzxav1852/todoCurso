package com.everis.examenuno.ejerciciodos;

import java.util.List;

public abstract class Servicio {
	public abstract void exportar(List<String>cadenas);
 
		
	
}

package com.everis.examenuno.ejerciciodos;

import java.util.List;

public class ServicioArchivo extends Servicio{
	public abstract void exportar(List<String>cadenas);
	 

}
